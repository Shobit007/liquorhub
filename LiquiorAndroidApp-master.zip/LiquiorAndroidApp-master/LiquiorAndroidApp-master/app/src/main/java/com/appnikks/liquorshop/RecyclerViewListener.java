package com.appnikks.liquorshop;

public interface RecyclerViewListener<T> {
    void onItemClicked(T model);
}
