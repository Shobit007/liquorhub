package com.appnikks.liquorshop;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;

public class CategoryModel {
    private int id;
    @NonNull
    private String name;
    @DrawableRes
    private int imageRes;

    public CategoryModel(int id, @NonNull String name, int imageRes) {
        this.id = id;
        this.name = name;
        this.imageRes = imageRes;
    }

    public int getId() {
        return id;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public int getImageRes() {
        return imageRes;
    }
}
