package com.appnikks.liquorshop;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;

public class LiquorItemModel {
    private int itemId;
    private int categoryId;
    @DrawableRes
    private int imageRes;
    @NonNull
    private String name;
    @NonNull
    private String details;
    private double rate;

    public LiquorItemModel(int itemId, int categoryId, int imageRes, @NonNull String name, @NonNull String details, double rate) {
        this.itemId = itemId;
        this.categoryId = categoryId;
        this.imageRes = imageRes;
        this.name = name;
        this.details = details;
        this.rate = rate;
    }

    public int getItemId() {
        return itemId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public int getImageRes() {
        return imageRes;
    }

    @NonNull
    public String getName() {
        return name;
    }

    @NonNull
    public String getDetails() {
        return details;
    }

    public double getRate() {
        return rate;
    }
}
