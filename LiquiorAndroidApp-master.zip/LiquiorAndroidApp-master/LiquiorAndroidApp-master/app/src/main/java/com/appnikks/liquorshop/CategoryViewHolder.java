package com.appnikks.liquorshop;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CategoryViewHolder extends RecyclerView.ViewHolder {

    @NonNull
    private RecyclerViewListener<CategoryModel> listener;

    private ImageView imageView;
    private TextView categoryName;

    public CategoryViewHolder(@NonNull View itemView, @NonNull RecyclerViewListener<CategoryModel> listener) {
        super(itemView);
        this.listener = listener;
        imageView = itemView.findViewById(R.id.image_category);
        categoryName = itemView.findViewById(R.id.text_category_name);
    }

    void bindData(@NonNull final CategoryModel model) {
        imageView.setImageResource(model.getImageRes());
        categoryName.setText(model.getName());
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClicked(model);
            }
        });
    }
}
