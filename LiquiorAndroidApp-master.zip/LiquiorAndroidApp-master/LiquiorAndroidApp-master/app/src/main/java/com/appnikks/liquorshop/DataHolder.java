package com.appnikks.liquorshop;

import java.util.ArrayList;

public class DataHolder {

    static ArrayList<CategoryModel> categoryModelArrayList = new ArrayList<>();
    static ArrayList<LiquorItemModel> liquorItemModelArrayList = new ArrayList<>();

    static {
        categoryModelArrayList.add(new CategoryModel(1, "Beer", R.drawable.beer));
        categoryModelArrayList.add(new CategoryModel(2, "Whiskey", R.drawable.whiskeyy));
        categoryModelArrayList.add(new CategoryModel(3, "vodka", R.drawable.vodkaa));
        categoryModelArrayList.add(new CategoryModel(4, "Rum",R.drawable.rumm));
        categoryModelArrayList.add(new CategoryModel(5, "Scotch",R.drawable.scoth));
        categoryModelArrayList.add(new CategoryModel(6, "Tequila", R.drawable.taquilla));

        // Vodka Items
        liquorItemModelArrayList.add(new LiquorItemModel(1, 3, R.drawable.vodka1, "Mgaic Moments", " It’s Magic When Purity Blends With Smoothness’, Magic Moments is a triple distilled, rice grain gluten-free vodka and launched back in 2006. Since then, it has won itself 36 international awards, not only for its standard variant but also its six flavors. Magic Moments prides itself on being a versatile product. In only seven years it is established in 24 countries around the world, and the UK is embracing the versatility of the flavors.\n" +
                "\nAlcohol By Volume Of Magic Moments: 37.5%\n" +
                "\n" +
                "PRICE OF MAGIC MOMENTS IN INDIA: Rs. 586 for 750ml", 586));


        liquorItemModelArrayList.add(new LiquorItemModel(2, 3, R.drawable.vodka2, "CliffHanger", " Made from Japanese white rice that gets filtered through bamboo charcoal in Osaka, Japan, this vodka is exceptionally clean, soft, and smooth, with a subtle sweetness.", 600.0));


        liquorItemModelArrayList.add(new LiquorItemModel(3, 3, R.drawable.vodka3, "Smirnoff", "Definitely the most consumed vodka in America, it is distilled three times and filtered 10 times before coming into the main scene. The discovery of the famous cocktail- Moscow Mule followed the creation of this vodka. Smirnoff is named after a person - Pyotr Smirnoff, he started out as a Russian Serf and went on to create the best-selling vodka in the world. The “flavorings” in the flavored versions might contain trace amounts of gluten, but plain old Smirnoff vodka is made from corn, making it totally gluten-free.\n"+
                "Alcohol By Volume Of Smirnoff: 37.5%\n" +
                        "\n" +
                        "PRICE OF SMIRNOFF IN INDIA: Rs. 1400 or 750ml.\n" +
                        "\n" +
                        " ", 1400.0));


        liquorItemModelArrayList.add(new LiquorItemModel(4, 3, R.drawable.vodka4, "ABSOLUTE", "Absolut is the third largest brand of alcoholic spirits in the world after Bacardi and Smirnoff and is sold in 126 countries. With 400 years of Swedish tradition behind it, this superb Vodka is extremely smooth. Using the purest Swedish water from the town of Ahus and wheat grown in the surrounding countryside, Absolut has maintained the tradition of pure and perfect Swedish Vodka. There are 27 different variants of this vodka and they make the most attractive bottles with extremely good-looking packaging.\n"+
              "  Alcohol By Volume Of Absolut: 40%  \n "+" PRICE OF ABSOLUT IN INDIA: Rs. 2000 For 750ml. ", 2000.0));


        //Beer
        liquorItemModelArrayList.add(new LiquorItemModel(1, 1, R.drawable.beer1, "Kingfisher", "Kingfisher Premium, one of the first mild beers to be launched under the Kingfisher umbrella, is associated with the Good Times in more ways than one. From music and food to sporting events, the brand will make sure that you always have the #GoodTimes!"+"\n"+"Alcohol by volume \t4.8%", 200.0));
        liquorItemModelArrayList.add(new LiquorItemModel(2, 1,R.drawable.beer2 , "ThunderBolt", "thunderbolt beer is aroma most complex features ,thunderbolt beer super strong beer,and rate wise is the best beer.so overall good beer. enjoy the beer./n"+"8 Percent Alcohol" , 200.0));
        liquorItemModelArrayList.add(new LiquorItemModel(3, 1, R.drawable.beer3, "Miller ACE", "Premium brewed smooth taste american style strong beer", 250.0));
        liquorItemModelArrayList.add(new LiquorItemModel(4, 1, R.drawable.beer6, "Butwiser", " Among the strongest beers made in the country, the Budweiser Magnum is possibly the most palatable. Notably smooth, crisp and easy to drink (and gets the job done a lot faster!). This mild-colored Australian lager is a full-bodied drink with a rather malty flavor, and it pairs nicely with classic sports night food.. \n "+ "Alcohol by volume\t 8%", 270.0));
        liquorItemModelArrayList.add(new LiquorItemModel(5, 1, R.drawable.beer5, "Heinekein", " Heineken is brewed using the finest water, malt and hops, along with yeast that is supplied from the Heineken headquarters in Zoeterwoude in the Netherlands."+"Alcohol 5%", 300.0));
        liquorItemModelArrayList.add(new LiquorItemModel(6, 1, R.drawable.beer5, "Corona", " Corona Extra contains barley malt, corn, hops, yeast, antioxidants (ascorbic acid), and propylene glycol alginate as a stabilizer.[7] Propylene glycol alginate is a synthetic, colorless, odorless, tasteless liquid that belongs to the same chemical class as alcohol"+"Alccohol percentage 4.5", 250.0));

        //Whiskey
        liquorItemModelArrayList.add(new LiquorItemModel(1, 2, R.drawable.whiskey1, "Imperial blue", "Imperial Blue, abbreviated to IB and also known as Seagram's Imperial Blue, is a brand of Indian whisky, owned by Pernod Ricard, and launched in 1997. It is a blend of Indian grain spirits with imported Scotch malts. "+"Alcohol percent 42%", 450.0));
        liquorItemModelArrayList.add(new LiquorItemModel(2, 2, R.drawable.whiskey2, "Royal Challgenger", " Royal Challenge, like most Indian \"whisky\", is actually a rum flavored to pass as whisky.\"[4] The manufacturer has refused to state the percentage of Scotch whisky used in the blend.[2] In the United States, Royal Challenge is referred to as \"spirit whisky\". Besides India, Royal Challenge is sold in several other countries including the Middle East and the United States."+"Alcohal 42.8", 550.0));
        liquorItemModelArrayList.add(new LiquorItemModel(3, 2, R.drawable.whiskey3, "Royal Stag", "It is Pernod Ricard's best selling brand by volume. It is a blend of grain spirits and imported Scotch malts. It is commonly available in" +"Alcohal 42.8%", 600.0));
        liquorItemModelArrayList.add(new LiquorItemModel(4, 2, R.drawable.whyskey4, "Blender's Pride", "Blenders Pride is a terrific blended whisky brands in India with an impressive fruity smoothness that is rarely found at a reasonable price."+"Alcohal 42.8%", 700.0));

        //scotch
        liquorItemModelArrayList.add(new LiquorItemModel(1, 5, R.drawable.scotch1, "Black and White", "Black & White is a blended Scotch whisky. It was originally produced by the London-based James Buchanan & Co Ltd founded by James Buchanan. Originally known as House of Commons"+"40%", 1100.0));
        liquorItemModelArrayList.add(new LiquorItemModel(2, 5, R.drawable.scotch2, "Teacher's", "Teacher's Highland Cream is a brand of blended Scotch whisky produced in Glasgow, Scotland, by Beam Suntory, the US-headquartered subsidiary of Suntory Holdings of Osaka, Japan"+"Alcohol -40%", 1200.0));
        liquorItemModelArrayList.add(new LiquorItemModel(3, 5, R.drawable.scotch3, "Ballantine", "Ballantine's is a range of Blended Scotch whiskies produced by Pernod Ricard in Dumbarton, Scotland. The Ballantine's flavour is dependent on fingerprint malts from Miltonduff and Glenburgie, blended with 50 single malts and four single grains. The brand has won many accolades and awards for its products."+"Alcohol - 40%", 1400.0));
        liquorItemModelArrayList.add(new LiquorItemModel(4, 5, R.drawable.scotch4, "Jameson", "Jameson is a blended Irish whiskey produced by the Irish Distillers subsidiary of Pernod Ricard. Originally one of the six main Dublin Whiskeys, Jameson is distilled at the New Midleton Distillery in County Cork"+"Alcohol - 35%", 250.0));
        liquorItemModelArrayList.add(new LiquorItemModel(5, 5, R.drawable.scotch5, "Johnnie Walker Blue Lable", "Johnnie Walker Blue Label is incomparably rich and smoky, with velvety smooth breaking waves of powerful flavour. Created from hand-selected casks of some of the rarest and most exceptional whiskies, there is no sensory experience quite like Johnnie Walker Blue Label."+"Alcohol - 35%", 18770.0));
        liquorItemModelArrayList.add(new LiquorItemModel(6, 5, R.drawable.scotch6, "Jack Danieals Honey", "A truly fabulous whiskey liqueur from Jack Daniel's. Jack Daniel's Honey is made with a mix of rich spices and smooth, supple honey and the result is delicious over ice or in coffee."+"Alcohol - 35%", 2760.0));
        liquorItemModelArrayList.add(new LiquorItemModel(7, 5, R.drawable.scotch7, "Jagger Meister", "Jagermeister is none of those liquors. It's a digestif, and has a lot of herbs and spices in it. It's basically ethanol, as all liquors are, but uses a lot of different ingredients that whiskey or rum wouldn't. Gin would be the most closely related, since it also uses botanicals to give flavour."+"Alcohol - 35%", 2070.0));
        liquorItemModelArrayList.add(new LiquorItemModel(8, 5, R.drawable.scotch8, "Black Dog", "Black Dog is a 100% genuine Scotch Whisky distilled, matured and blended in Scotland. ... Black Dog has a very distinctive taste and flavor. This classy whisky is available in 4 exciting blends"+"42.8", 1600.0));

        //Rum
        liquorItemModelArrayList.add(new LiquorItemModel(1, 4, R.drawable.rum1, "Old Monk", "Old Monk Rum is an iconic vatted Indian dark rum, launched in 1954. It is blended and aged for a minimum of 7 years. It is a dark rum with a distinct vanilla flavour"+"alcohol 42.8%", 500.0));
        liquorItemModelArrayList.add(new LiquorItemModel(2, 4, R.drawable.rum2, "Bacardi", "Bacardi Limited is the largest American privately held, family-owned spirits company in the world. Originally known for its eponymous Bacardi white rum, it now has a portfolio of more than 200 brands and labels.", 600.0));

        //tequila
        liquorItemModelArrayList.add(new LiquorItemModel(1, 6, R.drawable.tequila1, "Piedra Azul Reposado", "Piedra Azul Reposado is one of the most reasonably priced tequila brands which offers a sweet taste. It has notes of vanilla and caramel with a finishing touch of honey that enables you to swallow the shot with ease"+"alcohol 44%", 1200.0));

    }
}
