package com.appnikks.liquorshop;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeAdapter extends RecyclerView.Adapter<CategoryViewHolder> {

    private RecyclerViewListener<CategoryModel> listener;
    private ArrayList<CategoryModel> modelArrayList = new ArrayList<>();

    public HomeAdapter(@NonNull RecyclerViewListener<CategoryModel> listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CategoryViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item_layout, parent,false), listener);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        holder.bindData(modelArrayList.get(position));
    }

    public void submitList(List<CategoryModel> newList) {
        modelArrayList.clear();
        modelArrayList.addAll(newList);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return modelArrayList.size();
    }
}
