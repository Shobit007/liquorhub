package com.appnikks.liquorshop;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements RecyclerViewListener<CategoryModel> {

    private RecyclerView recyclerView;
    private HomeAdapter adapter = new HomeAdapter(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler_view_main);
        recyclerView.setAdapter(adapter);
        adapter.submitList(DataHolder.categoryModelArrayList);
    }

    @Override
    public void onItemClicked(CategoryModel model) {
        //TODO START ACTIVITY
    }
}
